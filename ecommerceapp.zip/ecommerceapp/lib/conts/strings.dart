const appname = "Shopping Mart";
const appversion = "Version 2.0.0";
const credits = "Hassan Ali";

const name = "Name";
const namehint = "Hassan Ali";
const email = 'Email';
const emailHint = "admin@admin.com";
const password = 'Password';
const PasswordHint = '******';
const retypepass = 'Retype password';
const forgotpass = "Forgot Password";
const log = "Log in";
const sign = "Sign up";
const create = 'Or Create new Account';
const login = "LogIn With";
const term = "Terms & Condition ";
const privacy = "Privacy Policy ";
const already = "Login Here";

const userlogin = "Log in Successfully!";

const home = "Home";
const cat = 'Categories';
const cart = "Cart";
const account = 'Account';

const search = "Search Anything...";
const today = "TodayDeal";
const flash = "FlashDeal";

const topcat = "Categories";
const brand = "Brand";
const topseller = "Top Seller";

const feature = "Feature Categories";

const WDress = "Women Dress";
const Gdress = "Girls Dress";
const BGlass = "Boy Glasses";
const Phone = "Phone";
const Tshirt = 'T shirt';
const GWatch = 'Girls Watches';

const featurep = "Feature Product";

const men = "Men Dress",
    laptop = "Laptop",
    auto = "Auto Mobile",
    kid = "Kid Toys",
    sport = "Sports",
    mobile = "Mobile ",
    mak = "Fashion ",
    clean = "Cleaning ",
    sofa = "Sofa Set",
    Gshoes = "Girls Shoes",
    bag = "Girls Bags",
    Bshoes = "Sports Shoes";

const subcat = "Baby Cloths";

//iteam button list

const video = "Video",
    review = "Review",
    seller = "Seller Policy",
    returnp = "Return Policy",
    support = "Support Policy";

const youmay = "Product you may also like ";

//Profile String

const wish = "My Wishlist", order = "My Order ", message = "Message";
