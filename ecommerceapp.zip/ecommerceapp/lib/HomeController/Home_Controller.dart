import 'package:ecommerceapp/conts/consts.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {

  var currentIndex = 0.obs;

}