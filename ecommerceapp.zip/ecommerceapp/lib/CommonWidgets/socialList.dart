import 'package:ecommerceapp/conts/consts.dart';

const socialicon = [
  icFacebookLogo,
  icGoogleLogo,
  icTwitterLogo,
];

const sliderlist = [
  imgSlider1,
  imgSlider2,
  imgSlider3,
  imgSlider4,
];

const Secondsliderlist = [
  imgSs1,
  imgSs2,
  imgSs3,
  imgSs4,
];

const featureimage1 = [
  imgS1,
  imgS2,
  imgS3,
];

const featureimage2 = [
  imgS1,
  imgS2,
  imgS3,
];

const featuretitle1 = [
  WDress,
  Gdress,
  BGlass,
  Phone,
  Tshirt,
  GWatch,
];
const featuretitle2 = [
  Phone,
  Tshirt,
  GWatch,
];

const GrideImage = [
  imgPi1,
  imgPi2,
  imgPi3,
  imgPi4,
  imgPi5,
  imgP4,
];

const featureproduct = [
  imgP1,
  imgP2,
  imgP3,
  imgP4,
  imgP5,
  imgP6,
];

const categoryimage = [
  imgFc1,
  imgFc2,
  imgFc3,
  imgFc4,
  imgFc5,
  imgFc6,
  imgFc7,
  imgFc8,
  imgFc9,
  imgP4,
  imgP5,
  imgP6,
];

const categorytitle = [
  men,
  laptop,
  auto,
  kid,
  sport,
  mobile,
  mak,
  clean,
  sofa,
  Gshoes,
  bag,
  Bshoes,
];

const iconbtn = [video, review, seller, returnp, support];

const profilebtn = [order, wish, message];

const profileiconbtn = [icMessages, icOrder, icMessages];
